# udemy-userAPI


![Versão](https://img.shields.io/badge/version-0.3.6-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://paulocesar-dev404.github.io/me-apoiando-online/)
[![Sponsor](https://img.shields.io/badge/Documentation-green)](https://github.com/PauloCesar-dev404/udemy-userAPI/blob/main/docs/iniciando.md)


Obtenha detalhes de cursos da plataforma udemy com a api de usuário,usando esta lib


- [x] Obter cursos inscritos(acesso por plano ou cursos free)
- [x] Obter detalhes de Aulas
- [x] Obter detalhes de um Curso

