__version__ = '0.3.5'
__lib_name__ = 'udemy_userAPI'  # local name
__repo_name__ = 'udemy-userAPI'
__autor__ = 'PauloCesar-dev404'
__repo__ = f'https://github.com/PauloCesar-dev404/{__repo_name__}'
__description__ = """Obtenha detalhes de cursos que o usuário esteja inscrito da plataforma Udemy,usando o EndPoint de usuário o mesmo que o navegador utiliza para acessar e redenrizar os cursos."""
