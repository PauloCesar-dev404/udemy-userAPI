# Biblioteca para análise de arquivos MPD
from .mpd_parser import MPDParser
__version__ = '0.1.0'
