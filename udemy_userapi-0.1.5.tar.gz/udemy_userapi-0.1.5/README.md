<div align="center">
    <img src="assets/udemy_userAPI-logo.png" alt="udemy_userAPI-logo" width="200"/>
  

![Versão](https://img.shields.io/badge/version-0.1.5-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://apoia.se/paulocesar-dev404)
[![Sponsor](https://img.shields.io/badge/Documentation-green)](https://github.com/PauloCesar-dev404/udemy-userAPI/wiki)


  <i>Obtenha detalhes completos de cursos cujo o usuário esteja inscrito ,da plataforma [Udemy](https://www.udemy.com/) com esta biblioteca</i>
  
  ---
</div>


###  Funcionalidades
- [x] Obter cursos inscritos (cursos com acesso por plano ou comprados ou cursos Grátis)
- [x] Obter detalhes de Aulas
- [x] Obter detalhes de um Curso

Se tiver dúvidas ou sugestões, abra uma [issue aqui](https://github.com/PauloCesar-dev404/udemy_userAPI/issues).

---

