# udemy-userAPI


![Versão](https://img.shields.io/badge/version-0.3.12-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://paulocesar-dev404.github.io/me-apoiando-online/)
[![Sponsor](https://img.shields.io/badge/Documentation-green)]()


Obtenha detalhes de cursos da plataforma udemy com a api de usuário,usando esta lib


- [x] Obter cursos inscritos(acesso por plano ou cursos free)
- [x] Obter detalhes de Aulas
- [x] Obter detalhes de um Curso

