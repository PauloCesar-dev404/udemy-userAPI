# udemy-userAPI


![Versão](https://img.shields.io/badge/version-0.2.4-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://apoia.se/paulocesar-dev404)
[![Sponsor](https://img.shields.io/badge/Documentation-green)](https://github.com/PauloCesar-dev404/udemy-userAPI/wiki)


Obtenha detalhes de cursos da plataforma udemy com a api de usuário,usando esta lib


- [x] Obter cursos inscritos(acesso por plano ou cursos free)
- [x] Obter detalhes de Aulas
- [x] Obter detalhes de um Curso

